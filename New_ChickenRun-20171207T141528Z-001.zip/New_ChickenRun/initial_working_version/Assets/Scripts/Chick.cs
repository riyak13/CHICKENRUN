﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chick : MonoBehaviour 
{
	private Rigidbody2D rgbd2d; 
	private bool chickDead = false;  // Chick is not dead by default
	public bool ChickRun = false;

	public float ForceUpward = 200f; // force for the chick to jump
	public float ChickRunningSpeed = 0.5f;
	private Animator animator;



	void Start () 
	{
		rgbd2d = GetComponent<Rigidbody2D> ();
		animator = GetComponent<Animator> ();
	}


	void Update () 
	{ if (chickDead == false ) //when the game starts, the chick is contantly running by default
		{	
			animator.SetTrigger ("run");

			 if (Input.GetMouseButtonDown(0)) // method to make the chick jump 
			{	
				rgbd2d.velocity = Vector2.zero;
				rgbd2d.AddForce (new Vector2 (0, ForceUpward));
				animator.SetTrigger ("fly");
			}
		} 

	}



	void OnCollisionEnter2D (Collision2D coll)
	{ if(coll.gameObject.name == "background" || coll.gameObject.name == "background2")
		{
			chickDead = false;
			animator.SetTrigger("run");
		}
		else if (coll.gameObject.name == "Berry" || coll.gameObject.name == "Water") 
		{
		GameControl.instance.ChickScored ();
		Destroy (coll.gameObject);
		}
		else if (coll.gameObject.name == "Stone" || coll.gameObject.name == "Eagle")
		{
//		rgbd2d.velocity = Vector2.zero;
		chickDead = true;
		animator.SetTrigger ("die");
		GameControl.instance.ChickDead();
	    }
		
   }



}












