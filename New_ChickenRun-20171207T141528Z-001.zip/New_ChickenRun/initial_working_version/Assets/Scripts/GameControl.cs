﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class GameControl : MonoBehaviour 
{
	public static GameControl instance; 


//	public GameObject GameOverText; //canvas text to be shown under defined situations
//	public Text ScoreText;


	public bool GameOver = false;

	private int score = 0;

	public float ScrollSpeed = -1.5f; // background scrolling speed



	void Awake () // game is under control of only one Game control
	{
		if (instance == null) 
		{
			instance = this;
		} 
		else if (instance != this) 
		{
			Destroy (gameObject);
		}
	}


	void Update () 
	{
		if (GameOver == true && Input.GetMouseButtonDown (0))  
		{
			SceneManager.LoadScene (SceneManager.GetActiveScene ().buildIndex);
		} 


	}




	public void ChickScored () //calculate score and display
	{
		if (GameOver) // if gameover, exit
		{
			return;
		}

		score = score + 100; //increase score by 100 when hit a powerup object
//		ScoreText.text = "Score: " + score.ToString (); // display the score when not gameover
	
	}

	public void ChickDead()
	{
//		GameOverText.SetActive (true);
		GameOver = true;
	}
}
