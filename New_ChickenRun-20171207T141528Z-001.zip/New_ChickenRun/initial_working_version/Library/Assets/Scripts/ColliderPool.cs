﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ColliderPool : MonoBehaviour 
{
	
	public GameObject ColliderPrefab;
	public int ColliderPoolSize = 3;
	public float SpawnRate = 5f; // how often to put a new collider
	public float ColliderMin = -4f;
	public float ColliderMax = 5.5f;

	private GameObject[] colliders;
	private Vector2 colliderPoolPosition = new Vector2 (-15f, -25f); //offscreen position  
	private float timeSinceLastSpawned; // time since the last collider appeared
	private float spawnPositionX = 10f; // position of new collider along X axis
	private int currentCollider = 0;


	void Start () 
	{
		timeSinceLastSpawned = 0f;
		colliders = new GameObject[ColliderPoolSize];
		for (int i = 0; i < ColliderPoolSize; i++) //loop through the array and create collider
		{
			colliders [i] = (GameObject)Instantiate (ColliderPrefab, colliderPoolPosition, Quaternion.identity); //instantiate objects, store in the array 
		}
	}
	

	void Update () //timer to check when to reposition new colliders
	{
		timeSinceLastSpawned += Time.deltaTime;
		if (GameControl.instance.GameOver == false && timeSinceLastSpawned >= SpawnRate) 
		{
			timeSinceLastSpawned = 0f;
			float spawnPositionY = Random.Range (ColliderMin, ColliderMax); // position of new collider along Y axis
			colliders[currentCollider].transform.position = new Vector2(spawnPositionX, spawnPositionY); //define X-Y coordinaates for current collider

			currentCollider++;

			if (currentCollider >= ColliderPoolSize) // make sure the number of colliders do not exceed the pool size
			{
				currentCollider = 0;
			}

		}
	}
}
