﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Colliders : MonoBehaviour 
{

	private void OnCollisionEnter2D(Collision2D col)
	{
//		if (col.gameObject.name == "Berry" || col.gameObject.name == "Water"  ) 
//		{
//			GameControl.instance.ChickScored ();
//			Destroy (col.gameObject);
//		}
//
//		else if(col.gameObject.name == "Stone" || col.gameObject.name == "Eagle")
//		{
//			GameControl.instance.ChickDead();
//		}

	}


}
